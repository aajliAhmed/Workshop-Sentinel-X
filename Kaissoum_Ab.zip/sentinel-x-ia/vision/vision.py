"""Vision : détection de personnes (YOLOv8n) sur la webcam USB du PC serveur.

- redimensionne chaque image en 640x480 et mesure le temps d'inférence ;
- dessine un cadre autour des personnes détectées ;
- envoie une alerte à l'API en cas de détection ;
- publie l'image annotée en flux MJPEG, affichable sur le dashboard
  avec <img src="http://IP_DU_SERVEUR:5000/video">.

Usage : python vision.py
Variables d'environnement (aucun secret dans le code) :
  CAMERA_INDEX (0)      CONFIANCE (0.5)       MODELE_YOLO (yolov8n.pt)
  API_URL (https://192.168.10.10/api/v1/alerts)   API_CA (certificat éventuel)
  DELAI_ALERTE (10 s)   HOTE_FLUX (0.0.0.0)   PORT_FLUX (5000)
"""
import os
import threading
import time

import cv2
import requests

LARGEUR, HAUTEUR = 640, 480


def traiter_image(modele, image, confiance=0.5):
    """Applique le modèle à une image 640x480.
    Retourne (image annotée, nombre de personnes, plus forte confiance, durée en ms)."""
    image = cv2.resize(image, (LARGEUR, HAUTEUR))
    debut = time.perf_counter()
    resultats = modele(image, classes=[0], conf=confiance, verbose=False)   # 0 = person
    duree_ms = (time.perf_counter() - debut) * 1000
    n, meilleure = 0, 0.0
    for boite in resultats[0].boxes:
        x1, y1, x2, y2 = (int(v) for v in boite.xyxy[0].tolist())
        score = float(boite.conf[0])
        n += 1
        meilleure = max(meilleure, score)
        cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 2)
        cv2.putText(image, f"personne {score:.2f}", (x1, max(y1 - 6, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    cv2.putText(image, f"{duree_ms:.0f} ms | {n} pers.", (8, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    return image, n, meilleure, duree_ms


class Alerteur:
    """Envoie une alerte à l'API, avec une pause pour ne pas l'inonder."""

    def __init__(self, delai=10, envoyer=None):
        self.delai = delai
        self.derniere = float("-inf")
        self.envoyer = envoyer or self._post

    def signaler(self, nb_personnes, confiance, maintenant=None):
        maintenant = time.time() if maintenant is None else maintenant
        if maintenant - self.derniere < self.delai:
            return False
        self.derniere = maintenant
        self.envoyer({"type": "intrusion_detectee", "source": "ia_vision",
                      "personnes": nb_personnes, "confiance": round(confiance, 3),
                      "ts": int(maintenant)})
        return True

    @staticmethod
    def _post(alerte):
        url = os.getenv("API_URL", "https://192.168.10.10/api/v1/alerts")
        try:
            requests.post(url, json=alerte, timeout=3,
                          verify=os.getenv("API_CA") or True)
            print("Alerte envoyée :", alerte)
        except requests.RequestException as e:
            print("Échec d'envoi de l'alerte :", e)


def creer_app(lire_jpeg):
    """Application Flask qui diffuse l'image annotée en MJPEG."""
    from flask import Flask, Response
    app = Flask(__name__)

    def flux():
        while True:
            jpeg = lire_jpeg()
            if jpeg:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpeg + b"\r\n")
            time.sleep(0.05)

    @app.route("/video")
    def video():
        return Response(flux(), mimetype="multipart/x-mixed-replace; boundary=frame")

    @app.route("/sante")
    def sante():
        return "ok"

    return app


def boucle_capture(modele, alerteur, derniere_image, confiance, index_camera):
    cap = cv2.VideoCapture(index_camera)
    if not cap.isOpened():
        raise SystemExit("Webcam introuvable : vérifiez CAMERA_INDEX et le branchement.")
    durees = []
    while True:
        ok, image = cap.read()
        if not ok:
            time.sleep(0.1)
            continue
        image, n, meilleure, duree = traiter_image(modele, image, confiance)
        if n > 0:
            alerteur.signaler(n, meilleure)
        ok, jpeg = cv2.imencode(".jpg", image)
        if ok:
            derniere_image["jpeg"] = jpeg.tobytes()
        durees.append(duree)
        if len(durees) == 100:
            print(f"Temps moyen d'inférence : {sum(durees) / 100:.0f} ms par image")
            durees.clear()


def main():
    from ultralytics import YOLO
    modele = YOLO(os.getenv("MODELE_YOLO", "yolov8n.pt"))
    alerteur = Alerteur(float(os.getenv("DELAI_ALERTE", "10")))
    derniere_image = {"jpeg": None}
    threading.Thread(
        target=boucle_capture, daemon=True,
        args=(modele, alerteur, derniere_image,
              float(os.getenv("CONFIANCE", "0.5")),
              int(os.getenv("CAMERA_INDEX", "0")))).start()
    app = creer_app(lambda: derniere_image["jpeg"])
    app.run(host=os.getenv("HOTE_FLUX", "0.0.0.0"),
            port=int(os.getenv("PORT_FLUX", "5000")), threaded=True)


if __name__ == "__main__":
    main()
