"""Détection d'anomalies en temps réel avec le modèle de l'équipe.

Chaîne : MQTT (mesures de l'ESP32) -> Isolation Forest -> alerte vers l'API.

Le modèle attendu est le fichier .joblib de l'équipe : un dictionnaire
{"model": IsolationForest, "features": ["temperature_C", "humidite_pct"], ...}.

Usage : python detecteur_temps_reel.py
Variables d'environnement (aucun secret dans le code) :
  MODELE        (défaut isolation_forest_model_2_.joblib)
  MQTT_HOST (192.168.10.10)  MQTT_PORT (1883)  MQTT_USER  MQTT_PASS
  MQTT_TOPIC    (défaut sentinel/capteurs)
  API_URL       (défaut https://192.168.10.10/api/v1/alerts)
  API_CA        (chemin du certificat si l'API est en auto-signé)
  DELAI_ALERTE  (secondes entre deux alertes, défaut 30)
"""
import json
import math
import os
import time

import joblib
import pandas as pd
import requests

# Noms acceptés dans le JSON de l'ESP32 pour chaque variable du modèle.
ALIAS = {
    "temperature_C": ["temperature_C", "temperature", "temp"],
    "humidite_pct": ["humidite_pct", "humidity", "humidite", "hum"],
}


def charger_modele(chemin):
    """Charge le dictionnaire de l'équipe et retourne (modèle, liste des variables)."""
    contenu = joblib.load(chemin)
    if isinstance(contenu, dict):
        return contenu["model"], list(contenu["features"])
    raise ValueError("Format inattendu : le fichier doit contenir un dictionnaire "
                     "avec les clés 'model' et 'features'.")


def extraire_mesure(message, variables):
    """Retourne {variable: valeur} à partir du JSON reçu, ou None si incomplet."""
    mesure = {}
    for var in variables:
        noms = ALIAS.get(var, [var])
        valeur = next((message[n] for n in noms if n in message), None)
        try:
            valeur = float(valeur)
        except (TypeError, ValueError):
            return None
        if math.isnan(valeur):          # lecture ratée du DHT22
            return None
        mesure[var] = valeur
    return mesure


class Detecteur:
    """Score chaque nouvelle mesure et décide s'il faut alerter."""

    def __init__(self, modele, variables, delai_alerte=30):
        self.modele = modele
        self.variables = variables
        self.delai_alerte = delai_alerte
        self.derniere_alerte = float("-inf")

    def evaluer(self, mesure, maintenant=None):
        """Retourne un dictionnaire d'alerte si anomalie (hors pause), sinon None."""
        maintenant = time.time() if maintenant is None else maintenant
        X = pd.DataFrame([mesure], columns=self.variables)
        if self.modele.predict(X)[0] != -1:
            return None
        if maintenant - self.derniere_alerte < self.delai_alerte:
            return None                      # évite d'inonder l'API
        self.derniere_alerte = maintenant
        return {
            "type": "anomalie_capteurs",
            "source": "ia_maintenance_predictive",
            "score": round(float(self.modele.decision_function(X)[0]), 4),
            "mesure": mesure,
            "ts": int(maintenant),
        }


def envoyer_alerte(alerte):
    url = os.getenv("API_URL", "https://192.168.10.10/api/v1/alerts")
    try:
        requests.post(url, json=alerte, timeout=3,
                      verify=os.getenv("API_CA") or True)
        print("Alerte envoyée :", alerte)
    except requests.RequestException as e:
        print("Échec d'envoi de l'alerte :", e)


def main():
    import paho.mqtt.client as mqtt

    modele, variables = charger_modele(
        os.getenv("MODELE", "isolation_forest_model_2_.joblib"))
    detecteur = Detecteur(modele, variables, float(os.getenv("DELAI_ALERTE", "30")))
    topic = os.getenv("MQTT_TOPIC", "sentinel/capteurs")
    print("Variables du modèle :", variables)

    def on_connect(client, userdata, flags, rc, *args):
        client.subscribe(topic)
        print(f"Connecté, abonné à {topic}")

    def on_message(client, userdata, msg):
        try:
            message = json.loads(msg.payload)
        except ValueError:
            return
        mesure = extraire_mesure(message, variables)
        if mesure is None:
            print("Message ignoré (champ manquant ou invalide) :", message)
            return
        alerte = detecteur.evaluer(mesure)
        if alerte:
            envoyer_alerte(alerte)

    try:                                    # paho-mqtt 2.x
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    except AttributeError:                  # paho-mqtt 1.x
        client = mqtt.Client()
    if os.getenv("MQTT_USER"):
        client.username_pw_set(os.getenv("MQTT_USER"), os.getenv("MQTT_PASS", ""))
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(os.getenv("MQTT_HOST", "192.168.10.10"),
                   int(os.getenv("MQTT_PORT", "1883")))
    client.loop_forever()


if __name__ == "__main__":
    main()
