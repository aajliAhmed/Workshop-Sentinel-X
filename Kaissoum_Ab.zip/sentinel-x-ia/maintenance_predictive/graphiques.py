"""Graphiques de la maintenance prédictive pour le rapport.

Usage : python graphiques.py data.csv isolation_forest_model.joblib
Crée quatre images dans le dossier courant :
  1. graphe-series.png      mesures dans le temps et anomalies détectées
  2. graphe-frontiere.png   température / humidité et zone apprise par le modèle
  3. graphe-score.png       score d'anomalie dans le temps
  4. graphe-distribution.png répartition des températures et humidités
"""
import sys

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ORANGE, BLEU, ROUGE, GRIS = "#E8742A", "#378ADD", "#C0262D", "#8A97AD"


def charger(donnees, chemin_modele):
    contenu = joblib.load(chemin_modele)
    modele, features = contenu["model"], list(contenu["features"])
    df = pd.read_csv(donnees).dropna(subset=features)
    df["anomalie"] = modele.predict(df[features]) == -1
    df["score"] = modele.decision_function(df[features])
    df["heure"] = pd.to_datetime(df["horaire"], format="%H:%M:%S")
    return df, modele, features


def graphe_series(df):
    fig, axes = plt.subplots(2, 1, figsize=(10, 5.2), sharex=True)
    for ax, col, titre, couleur in [(axes[0], "temperature_C", "Température (°C)", ORANGE),
                                    (axes[1], "humidite_pct", "Humidité (%)", BLEU)]:
        ax.plot(df["heure"], df[col], lw=0.8, color=couleur, label="mesures")
        ax.scatter(df.loc[df["anomalie"], "heure"], df.loc[df["anomalie"], col],
                   s=12, color=ROUGE, zorder=3, label="anomalie détectée")
        ax.set_ylabel(titre)
        ax.grid(alpha=0.3)
    axes[0].legend(loc="upper right", fontsize=8)
    axes[1].xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    axes[1].set_xlabel("Heure")
    fig.suptitle("Mesures du DHT22 et anomalies détectées", fontsize=11)
    fig.tight_layout()
    fig.savefig("graphe-series.png", dpi=200)
    plt.close(fig)


def graphe_frontiere(df, modele, features):
    t_min, t_max = df["temperature_C"].min() - 2, df["temperature_C"].max() + 2
    h_min, h_max = df["humidite_pct"].min() - 5, df["humidite_pct"].max() + 5
    tt, hh = np.meshgrid(np.linspace(t_min, t_max, 300), np.linspace(h_min, h_max, 300))
    grille = pd.DataFrame({features[0]: tt.ravel(), features[1]: hh.ravel()})
    zz = modele.decision_function(grille).reshape(tt.shape)

    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    ax.contourf(tt, hh, zz, levels=[zz.min(), 0], colors=["#F6D6D6"], alpha=0.8)
    ax.contour(tt, hh, zz, levels=[0], colors=[ROUGE], linewidths=1.2)
    normal = df[~df["anomalie"]]
    anormal = df[df["anomalie"]]
    ax.scatter(normal["temperature_C"], normal["humidite_pct"], s=6, color=GRIS,
               alpha=0.6, label="mesure normale")
    ax.scatter(anormal["temperature_C"], anormal["humidite_pct"], s=14, color=ROUGE,
               label="anomalie détectée")
    ax.plot([], [], color=ROUGE, lw=1.2, label="frontière apprise par le modèle")
    ax.set_xlabel("Température (°C)")
    ax.set_ylabel("Humidité (%)")
    ax.set_title("Zone de fonctionnement normal apprise par l'Isolation Forest", fontsize=11)
    ax.legend(fontsize=8, loc="upper right")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("graphe-frontiere.png", dpi=200)
    plt.close(fig)


def graphe_score(df):
    fig, ax = plt.subplots(figsize=(10, 3.4))
    ax.plot(df["heure"], df["score"], lw=0.8, color=BLEU, label="score d'anomalie")
    ax.axhline(0, color=ROUGE, lw=1, ls="--", label="limite normal / anormal")
    ax.scatter(df.loc[df["anomalie"], "heure"], df.loc[df["anomalie"], "score"],
               s=10, color=ROUGE, zorder=3)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.set_xlabel("Heure")
    ax.set_ylabel("Score")
    ax.set_title("Score d'anomalie (négatif = anomalie)", fontsize=11)
    ax.legend(fontsize=8, loc="lower right")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("graphe-score.png", dpi=200)
    plt.close(fig)


def graphe_distribution(df):
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    for ax, col, titre, couleur in [(axes[0], "temperature_C", "Température (°C)", ORANGE),
                                    (axes[1], "humidite_pct", "Humidité (%)", BLEU)]:
        ax.hist(df.loc[~df["anomalie"], col], bins=40, color=couleur, alpha=0.8,
                label="normal")
        ax.hist(df.loc[df["anomalie"], col], bins=40, color=ROUGE, alpha=0.8,
                label="anomalie")
        ax.set_xlabel(titre)
        ax.set_ylabel("Nombre de mesures")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
    fig.suptitle("Répartition des mesures", fontsize=11)
    fig.tight_layout()
    fig.savefig("graphe-distribution.png", dpi=200)
    plt.close(fig)


def main():
    donnees = sys.argv[1] if len(sys.argv) > 1 else "data.csv"
    chemin_modele = sys.argv[2] if len(sys.argv) > 2 else "isolation_forest_model.joblib"
    df, modele, features = charger(donnees, chemin_modele)
    graphe_series(df)
    graphe_frontiere(df, modele, features)
    graphe_score(df)
    graphe_distribution(df)
    print("Images créées : graphe-series.png, graphe-frontiere.png, "
          "graphe-score.png, graphe-distribution.png")


if __name__ == "__main__":
    main()
