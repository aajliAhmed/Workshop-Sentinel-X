"""Évaluation du modèle sur les données et graphique pour le rapport.

Usage : python evaluer_modele.py data.csv isolation_forest_model.joblib
Affiche les chiffres de la section « Entraînement et validation » et crée
detection-anomalies.png.
"""
import sys

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd

# Intervalles utilisés pour qualifier un point d'« extrême » dans le rapport
TEMP_MIN, TEMP_MAX = 20, 30
HUM_MIN, HUM_MAX = 30, 85


def main():
    donnees = sys.argv[1] if len(sys.argv) > 1 else "data.csv"
    chemin_modele = sys.argv[2] if len(sys.argv) > 2 else "isolation_forest_model.joblib"
    contenu = joblib.load(chemin_modele)
    modele, features = contenu["model"], list(contenu["features"])

    df = pd.read_csv(donnees).dropna(subset=features)
    df["anomalie"] = modele.predict(df[features]) == -1
    heure = pd.to_datetime(df["horaire"], format="%H:%M:%S")

    # Chiffres généraux
    n, n_anom = len(df), int(df["anomalie"].sum())
    duree = heure.iloc[-1] - heure.iloc[0]
    pas = heure.diff().dt.total_seconds().mode()[0]
    print(f"Mesures : {n}, une toutes les {pas:.0f} s, durée {duree}")
    print(f"Anomalies détectées : {n_anom} ({n_anom / n:.1%})")

    # Points extrêmes et part détectée
    extreme = ((df["temperature_C"] < TEMP_MIN) | (df["temperature_C"] > TEMP_MAX) |
               (df["humidite_pct"] < HUM_MIN) | (df["humidite_pct"] > HUM_MAX))
    print(f"Points extrêmes : {int(extreme.sum())}, dont détectés : "
          f"{int((extreme & df['anomalie']).sum())}")
    print(f"Alertes sur des valeurs dans les intervalles : "
          f"{int((df['anomalie'] & ~extreme).sum())}")

    # Graphique
    fig, axes = plt.subplots(2, 1, figsize=(10, 5.2), sharex=True)
    for ax, col, titre, couleur in [
            (axes[0], "temperature_C", "Température (°C)", "#E8742A"),
            (axes[1], "humidite_pct", "Humidité (%)", "#378ADD")]:
        ax.plot(heure, df[col], lw=0.8, color=couleur, label="mesures")
        ax.scatter(heure[df["anomalie"]], df.loc[df["anomalie"], col], s=12,
                   color="#C0262D", zorder=3, label="anomalie détectée")
        ax.set_ylabel(titre)
        ax.grid(alpha=0.3)
    axes[0].legend(loc="upper right", fontsize=8)
    axes[1].xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    axes[1].set_xlabel("Heure")
    fig.suptitle("Isolation Forest : mesures du DHT22 et anomalies détectées", fontsize=11)
    fig.tight_layout()
    fig.savefig("detection-anomalies.png", dpi=200)
    print("Graphique enregistré : detection-anomalies.png")


if __name__ == "__main__":
    main()
