"""Collecte des mesures normales du boîtier dans un CSV (pour l'entraînement).

Usage : python collecter.py            (Ctrl+C pour arrêter)
Réglages par variables d'environnement (aucun secret dans le code) :
  MQTT_HOST (défaut 192.168.10.10)   MQTT_PORT (défaut 1883)
  MQTT_USER, MQTT_PASS               MQTT_TOPIC (défaut sentinel/capteurs)
  CSV_SORTIE (défaut data_normale.csv)
"""
import csv
import json
import os
import time

COLONNES = ["ts", "temperature", "humidity", "gas"]


def ligne_depuis_message(payload: bytes):
    """Transforme un message JSON du boîtier en ligne CSV (ou None si invalide)."""
    try:
        m = json.loads(payload)
        return [m.get("ts", int(time.time())),
                float(m["temperature"]), float(m["humidity"]), float(m["gas"])]
    except (ValueError, KeyError, TypeError):
        return None


def main():
    import paho.mqtt.client as mqtt

    sortie = os.getenv("CSV_SORTIE", "data_normale.csv")
    nouveau = not os.path.exists(sortie)
    fichier = open(sortie, "a", newline="")
    ecrivain = csv.writer(fichier)
    if nouveau:
        ecrivain.writerow(COLONNES)

    topic = os.getenv("MQTT_TOPIC", "sentinel/capteurs")

    def on_connect(client, userdata, flags, rc, *args):
        client.subscribe(topic)
        print(f"Connecté, abonné à {topic}")

    def on_message(client, userdata, msg):
        ligne = ligne_depuis_message(msg.payload)
        if ligne:
            ecrivain.writerow(ligne)
            fichier.flush()
            print(ligne)

    try:                                    # paho-mqtt 2.x
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    except AttributeError:                  # paho-mqtt 1.x
        client = mqtt.Client()
    if os.getenv("MQTT_USER"):
        client.username_pw_set(os.getenv("MQTT_USER"), os.getenv("MQTT_PASS", ""))
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(os.getenv("MQTT_HOST", "192.168.10.10"),
                   int(os.getenv("MQTT_PORT", "1883")))
    client.loop_forever()


if __name__ == "__main__":
    main()
