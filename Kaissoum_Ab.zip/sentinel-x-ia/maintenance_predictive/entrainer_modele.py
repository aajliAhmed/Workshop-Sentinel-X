"""Entraînement du modèle de maintenance prédictive (Isolation Forest).

Reproduit le modèle de l'équipe : deux variables du DHT22 (température et
humidité), 200 arbres, contamination de 3 %, graine aléatoire 42.

Usage : python entrainer_modele.py data.csv
Sortie : isolation_forest_model.joblib, un dictionnaire
         {"model", "features", "contamination", "n_estimators", "random_state"}
         lisible par detecteur_temps_reel.py.
"""
import sys

import joblib
import pandas as pd
from sklearn.ensemble import IsolationForest

FEATURES = ["temperature_C", "humidite_pct"]
CONTAMINATION = 0.03
N_ESTIMATORS = 200
RANDOM_STATE = 42


def charger_donnees(chemin):
    df = pd.read_csv(chemin)
    manquantes = [c for c in FEATURES if c not in df.columns]
    if manquantes:
        raise SystemExit(f"Colonnes absentes du CSV : {manquantes}")
    df = df.dropna(subset=FEATURES)          # lectures ratées du DHT22
    return df


def entrainer(df):
    modele = IsolationForest(n_estimators=N_ESTIMATORS,
                             contamination=CONTAMINATION,
                             random_state=RANDOM_STATE)
    modele.fit(df[FEATURES])
    return modele


def main():
    chemin = sys.argv[1] if len(sys.argv) > 1 else "data.csv"
    sortie = sys.argv[2] if len(sys.argv) > 2 else "isolation_forest_model.joblib"
    df = charger_donnees(chemin)
    modele = entrainer(df)
    joblib.dump({"model": modele, "features": FEATURES,
                 "contamination": CONTAMINATION, "n_estimators": N_ESTIMATORS,
                 "random_state": RANDOM_STATE}, sortie)
    n_anomalies = int((modele.predict(df[FEATURES]) == -1).sum())
    print(f"{len(df)} mesures utilisées, {n_anomalies} anomalies "
          f"({n_anomalies / len(df):.1%}) -> modèle enregistré dans {sortie}")


if __name__ == "__main__":
    main()
