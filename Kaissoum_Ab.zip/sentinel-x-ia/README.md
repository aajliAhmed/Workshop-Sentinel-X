# Sentinel-X — Partie Intelligence Artificielle

Modules d'intelligence artificielle du projet **Mission Sentinel-X**
(Workshop EPSI Bac+4, groupe 10). Deux briques indépendantes :

- **Maintenance prédictive** : détection d'anomalies sur les mesures du capteur
  DHT22 (température, humidité) avec un modèle *Isolation Forest* (scikit-learn).
- **Vision** : détection de personnes sur la webcam USB avec *YOLOv8n*
  (Ultralytics), envoi d'alertes et diffusion du flux annoté pour le dashboard.

Les deux modules envoient leurs alertes au backend via `POST /api/v1/alerts`.

## Arborescence

```
sentinel-x-ia/
├── maintenance_predictive/
│   ├── data.csv                      # mesures DHT22 (horaire, temperature_C, humidite_pct)
│   ├── isolation_forest_model.joblib # modèle entraîné (200 arbres, contamination 3 %)
│   ├── entrainer_modele.py           # entraîne et enregistre le modèle
│   ├── evaluer_modele.py             # chiffres + graphe detection-anomalies.png
│   ├── graphiques.py                 # 4 graphiques pour le rapport
│   ├── detecteur_temps_reel.py       # MQTT -> modèle -> alerte API (temps réel)
│   └── collecter.py                  # enregistre les mesures de l'ESP32 dans un CSV
├── vision/
│   └── vision.py                     # YOLOv8n sur webcam + flux MJPEG + alertes
├── requirements.txt
├── .env.example                      # modèle de configuration (copier en .env)
├── .gitignore
└── LICENSE
```

## Installation

```bash
python -m venv .venv
source .venv/bin/activate        # Windows : .venv\Scripts\activate
pip install -r requirements.txt
```

> Le modèle a été entraîné avec **scikit-learn 1.3.2** ; la même version est
> fixée dans `requirements.txt` pour garantir des résultats identiques.

## Maintenance prédictive

Entraîner le modèle à partir des données :

```bash
cd maintenance_predictive
python entrainer_modele.py data.csv
```

Évaluer le modèle et produire le graphique du rapport :

```bash
python evaluer_modele.py data.csv isolation_forest_model.joblib
python graphiques.py data.csv isolation_forest_model.joblib
```

Détection en temps réel (broker MQTT et ESP32 requis) :

```bash
cp ../.env.example ../.env     # puis renseigner les valeurs
python detecteur_temps_reel.py
```

**Choix du modèle.** L'Isolation Forest apprend la zone de fonctionnement
normale (combinaisons température/humidité) et signale les écarts. Aucun seuil
statique (`if temp > 40`) n'est utilisé, conformément au cahier des charges.

## Vision

```bash
cd vision
python vision.py
```

- détecte uniquement la classe `person` (seuil de confiance 0,5) ;
- redimensionne les images en 640×480 et mesure le temps d'inférence ;
- envoie une alerte `intrusion_detectee` à l'API (au plus une toutes les 10 s) ;
- diffuse le flux annoté sur `http://IP_DU_SERVEUR:5000/video`, affichable sur
  le dashboard via `<img src="...">`.

Au premier lancement, `yolov8n.pt` est téléchargé automatiquement.

## Configuration et secrets

Aucun secret n'est écrit dans le code. Tous les paramètres (adresse du broker,
identifiants, URL de l'API) passent par des variables d'environnement, décrites
dans `.env.example`. Le fichier `.env` réel est exclu du dépôt par `.gitignore`.

## Format des alertes

```json
{ "type": "anomalie_capteurs", "source": "ia_maintenance_predictive",
  "score": -0.03, "mesure": {"temperature_C": 24.6, "humidite_pct": 54.6},
  "ts": 1790000000 }
```

```json
{ "type": "intrusion_detectee", "source": "ia_vision",
  "personnes": 1, "confiance": 0.87, "ts": 1790000000 }
```

## Auteurs

Groupe 10 — EPSI Toulouse, filière Intelligence Artificielle.
